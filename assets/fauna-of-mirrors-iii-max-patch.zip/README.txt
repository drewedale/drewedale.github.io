FAUNA OF MIRRORS III — Max performance patch

MaxPatch.maxpat is the tape and click-track playback patch supplied in the original project archive. It routes stereo tape to outputs 1–2 and performer click cues to outputs 3–7. The patch references Tape.wav and Metro_Stereo.wav in playlist~ objects using relative filenames. Those large original WAV files are not included here. To reproduce the performance, supply the original audio, relink the two playlist~ objects to local copies, and configure a suitable multichannel audio interface.

The patch is provided as a source example and has not been tested against the original performance rig.
