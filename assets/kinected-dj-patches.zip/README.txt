THE KINECTED DJ — selected Max source

Open kinectDJ.maxpat in Max/MSP with these companion patchers in the same folder. The companion files are selected because their patcher names appear as objects in the main instrument.

The paper (available separately on the portfolio) describes the original system: Xbox Kinect, KinectV2-OSC, OSC across a local network, Rekordbox, a DDJ-400 controller, and audio routing through Max. Calibrate the tracked positions for the current performer before mapping them to effects.

This archive is a historical project source selection. The main patch also contains or refers to third-party effect modules and Max for Live objects that may require external packages, particular versions, and extra setup. A Max license, hardware, and the original runtime environment are required; it has not been verified as a one-click working build.

Included files:
 - kinectDJ.maxpat
 - calibrate.maxpat
 - distanceFormula.maxpat
 - echoDelay.maxpat
 - feedbackCutoff.maxpat
 - M4L.vdelay~.maxpat
 - phaser.maxpat
 - pitchShifter.maxpat
 - polyComb.maxpat
 - quiz4Flanger~.maxpat
 - RingModulator.maxpat
 - Tremolo.maxpat
 - YafrOp.maxpat
