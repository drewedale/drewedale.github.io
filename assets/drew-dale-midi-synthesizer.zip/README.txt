Drew Dale — MIDI Synthesizer (Max/MSP)

Open Drew_Dale_MIDI_Synthesizer.maxpat in Max. Turn on DSP and play MIDI notes from a connected MIDI device. The instrument exposes waveform selection, timbre and wave-squeeze controls, ADSR, portamento, vibrato, tremolo, and chord intervals. Its subpatchers and generated wave tables are embedded in the main patch.

This is source from an audio programming assignment. It has been inspected statically but not performance-tested in Max for this portfolio release.
