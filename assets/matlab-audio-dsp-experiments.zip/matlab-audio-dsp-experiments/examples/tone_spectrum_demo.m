% Self-contained demonstration using generated mono audio.
projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));

Fs = 48000;
tone = sineWave(2, 220, 0.35, 0, Fs) + ...
       sineWave(2, 440, 0.25, 0, Fs);
processed = hardClipper(tone, 0.45);

N = 4096;
window = 0.5 - 0.5*cos(2*pi*(0:N-1)'/(N-1));
X = fft(processed(1:N).*window);
magSpec = abs(X(1:N/2+1));
frequencies = bin2freq(0:N/2, N, Fs);
centroid = specCentroid(magSpec, Fs);
spread = specSpread(magSpec, centroid, Fs);

outputDir = fullfile(projectRoot, 'output');
if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end
audiowrite(fullfile(outputDir, 'tone_demo.wav'), processed, Fs);

figure;
subplot(2,1,1);
plot((0:999)/Fs, processed(1:1000));
xlabel('Time (s)'); ylabel('Amplitude'); title('Clipped two-tone signal');
subplot(2,1,2);
plot(frequencies, magSpec);
xlim([0 2000]);
xlabel('Frequency (Hz)'); ylabel('Magnitude'); title('Windowed spectrum');

fprintf('Spectral centroid: %.1f Hz; spread: %.1f Hz\n', centroid, spread);
