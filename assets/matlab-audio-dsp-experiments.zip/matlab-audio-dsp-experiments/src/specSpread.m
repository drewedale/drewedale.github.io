% this function takes a single frame of N / 2 + 1 magnitudes and returns the
% spectrum spread in units of Hz
function s = specSpread (magSpec, c, Fs)

    % calculate N
    N = (length (magSpec) - 1) * 2;

    totalEnergySum = sum (magSpec);

    % % initialize a sum variable
    % totalEnergy = 0;
    % 
    % % calculate the bottom term of the centroid (sum of all magnitudes)
    % for k = 1 : length (magSpec)
    % 
    %     totalEnergy = totalEnergy + magSpec(k);
    % 
    % end


    weightedEnergy = 0;

    for k = 1 : length (magSpec)

        % calculate the frequency for bin k
        f = bin2freq (k - 1, N, Fs);
        w = (f - c) ^ 2;

        weightedEnergy = weightedEnergy + (w * magSpec(k));

    end

    if totalEnergySum>0

        s = sqrt (weightedEnergy / totalEnergySum);
    else 
        s=0;
    end

end
