function c=specCentroid(magSpec, Fs)
    N=(length(magSpec)-1)*2;
    totalEnergy=0;
    for k=1:length(magSpec)
        
        totalEnergy=totalEnergy+magSpec(k);
    
    end
    
    weightedEnergy=0;
    for k=1:length(magSpec)
        f=bin2freq(k-1,N,Fs);
        weightedEnergy=weightedEnergy+(f*magSpec(k));
    end
    
    if totalEnergy>0
        c=weightedEnergy/totalEnergy;
    else
        c=Fs/4;
    end
end