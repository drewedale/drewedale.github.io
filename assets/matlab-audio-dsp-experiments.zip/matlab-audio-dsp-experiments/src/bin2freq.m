function f=bin2freq(b,N,Fs)
binWidth=Fs/N;
f=b*binWidth;
end