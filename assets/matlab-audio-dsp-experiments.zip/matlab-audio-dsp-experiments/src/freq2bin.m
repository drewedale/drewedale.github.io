function b=freq2bin(f,N,Fs)
b=round((N*f)/Fs);
end