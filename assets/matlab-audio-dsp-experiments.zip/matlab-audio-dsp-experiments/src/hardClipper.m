function y= hardClipper (x, thresh)

N = length(x);
y= zeros(N,1);
for n = 1:N
    if x(n) > thresh
        y(n) = thresh;
    elseif x(n) < -thresh
        y(n) = -thresh;
    else 
        y(n) = x(n);
    end
end
end