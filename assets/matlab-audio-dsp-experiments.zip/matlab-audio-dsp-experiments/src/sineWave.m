function x=sineWave(duration, frequency, amplitude, phase, Fs)

N=round(duration*Fs);
Ts=1/Fs;
t=(0:(N-1))*Ts;
t=t';
x=amplitude*sin(2*pi*frequency*t+phase);

end