# MATLAB Audio DSP Experiments

Selected MATLAB exercises in sound synthesis, amplitude processing, and spectral analysis. The functions in `src/` come from my 2023 audio programming coursework; `examples/tone_spectrum_demo.m` combines them into a self-contained demonstration using generated audio.

## Run the demo

Open the repository folder in MATLAB and run:

```matlab
run("examples/tone_spectrum_demo.m")
```

The demo creates a two-second two-tone signal, applies hard clipping, writes `output/tone_demo.wav`, plots its waveform and magnitude spectrum, and prints the spectrum's centroid and spread. It uses base MATLAB functions and needs no downloaded audio file. The example is designed around mono column vectors.

## Included functions

| File | Purpose |
| --- | --- |
| [`sineWave.m`](src/sineWave.m) | Generate a sine wave with duration, frequency, amplitude, phase, and sample-rate controls. |
| [`hardClipper.m`](src/hardClipper.m) | Constrain a mono signal to a chosen amplitude threshold. |
| [`freq2bin.m`](src/freq2bin.m), [`bin2freq.m`](src/bin2freq.m) | Convert between FFT bin indices and frequencies. |
| [`specCentroid.m`](src/specCentroid.m) | Calculate a magnitude-weighted spectral centroid. |
| [`specSpread.m`](src/specSpread.m) | Calculate magnitude-weighted spread around the centroid. |

## Project status

This is a curated educational project, not a production audio library. The source functions are preserved from the original exercises. MATLAB was unavailable during repository preparation, so the demo has been reviewed statically but has not been executed in MATLAB. In particular, the functions assume valid inputs and do not yet cover silent spectra, stereo channels, or other edge cases.

The broader coursework archive also contains framing, spectrogram, FFT-filtering, chroma, and zero-crossing experiments. Several of those drafts need missing input audio, dependency fixes, or completed algorithms, so they are not presented here as working tools. They can be added as separate examples after repair and verification.
